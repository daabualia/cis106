---
name: Dana
course: cis106
semester: fall 2023
---


![image](image1.1.jpg)
# Dana Abualia

46 wall st, lodi, NJ 07424
9732203277

## Objective
I aspire to find a a position where I can use my skills in interacting and make preparations to provide a positive and creatively a supportive environment for the children to grow and learn.

## Skills
* Able to work with children at different ages.
* Able ot help reading, writing, arts abd crafts to children.
* Abiltty to help in teaching lesson plans, directions and instructions of the Lead Teacher and program Teacher.
* Excellent communication and writing skills.
* Computer software skills, word, excel, powerpoint.

## Work History
* Assistance teacher in Islamic Sunday School. Anaheim, California.
* Manger at Mcdonald's for 2004_2008.
  




## Skills
* Able to work with children at different ages.
* Able to help in reading, writing, arts and crafts to children.
* Ability to help in teaching lessons.
* Excellent communication and writing skills.
* Computer software skills, work, excel, powerpoint.
* Reinforcing and supporting instructions.
* preparing materials and equipment.
* Helping students to use computers and educational software program.
* Over seen the entire operation.
* managed up to 25 employees.
* Control food cost and lower waste percentage.
* Responsible for other duties as assigned.


## Education 
Second year of University of child Devolpment. 

 
